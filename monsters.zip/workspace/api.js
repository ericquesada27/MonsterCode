var mongoose = require('mongoose');
var jwt        = require("jsonwebtoken");
var express = require('express');
var app = express();

// Models
var Perfil     = require('models/Perfil');

// Conecta-se o Banco de Dados
mongoose.connect('mongodb://localhost:27017/diapersdb');//Banco de Dados

app.use(express.bodyParser());

// Evitar uso em navegadores ou qualquer tipo de get
app.get('*', function(req, res) {
  res.send('Pagina não encontrada!');
});

// Autenticacao de usuario

//******* Utilize sempre o campo validation para verificar se não houve erro ********

app.post('/insert_crud', function(req, res) {
Perfil.findOne({model: req.body.model}, function(err, perfil) {
        if (err) {
            res.json({
                validation: false //Se ocorrer um erro o JSON retorna false no campo validation, verificar esse valor no Browser
            });
        } else {
            if (perfil) {
                res.json({
                        validation: true,    // validation retorna TRUE se encontrou dados
                        model: perfil.model, 
                        description: perfil.description,
                        size: perfil.size,
                        avl_qtt: perfil.avl_qtt,
                        pur_qtt: perfil.pur_qtt   //Colocar todos os campos que vc deseja receber no Browser, devera ser alterado tmb o arquivo node_modules/models/Perfil.js
                       
                        
                });
            } else {
                var perfilrModel = new Perfil();
                perfilrModel.model = req.body.model;
                perfilrModel.description = req.body.description;
                perfilrModel.size = req.body.size;
                perfilrModel.avl_qtt = req.body.avl_qtt; //Colocar todos os campos que vc deseja receber no Browser, devera ser alterado tmb o arquivo node_modules/models/Perfil.js
                perfilrModel.pur_qtt = req.body.pur_qtt;

                
                // Realiza o insert do Perfil
                perfilrModel.save(function(err, perfil) {
                        res.json({
                        validation: true,   
                        model: perfilrModel.model, 
                        description: perfilrModel.description,
                        size: perfilrModel.size,
                        avl_qtt: perfilrModel.avl_qtt,   //Colocar todos os campos que vc deseja receber no Browser, devera ser alterado tmb o arquivo node_modules/models/Perfil.js
                        pur_qtt: perfilrModel.pur_qtt
                       
                        });
                })
            }
        }
    });
});
// Fim da Autenticacao

// Atualizar Perfil
// *** ESTE ENDPOINT REALIZA A ATUALIZACAO DOS DADOS DO USUARIO, CHAMAR SEMPRE QUE HOUVER ALTERACAO
app.post('/update_crud', function(req, res) {
Perfil.findOne({model: req.body.model}, function(err, perfil) {
        if (err) {
            res.json({
                validation: false
            });
        } else {
            if (perfil) {
                perfil.model = req.body.model;
                perfil.description = req.body.description;
                perfil.size = req.body.size;
                perfil.avl_qtt = req.body.avl_qtt; //Colocar todos os campos que vc deseja receber no Browser, devera ser alterado tmb o arquivo node_modules/models/Perfil.js
                perfil.pur_qtt = req.body.pur_qtt;
                
                //Realiza a atualizacao dos dados
                perfil.save(function(err, perfil) {
                        res.json({
                            validation: true   
                        });
                });                
            } else {
                res.json({
                    validation: false
                });
            }
        }
    });
});
// Fim

// Evita que o servidor node.js pare se ocorrer algum erro
process.on('uncaughtException', function(err) {
console.log(err);
});

// Aplicação disponível 
app.listen(process.env.PORT || 3000, process.env.IP || "0.0.0.0");
